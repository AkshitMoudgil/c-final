﻿namespace FinalExam_200535888;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("FINALEXAM-200535888");
        student student_info = new student();
        student_info.FirstName = "Akshit";
        student_info.LastName = "Moudgil";
        student_info.Address = "206 Cardinal Street";
        student_info.PhoneNumber = "7057709529";

        resource resources_a = new resource();
        resources_a.Code = "https://www.worldcat.org/title/1112379554";
        resources_a.Title = "Harry Potter and the goblet of fire";
        resources_a.Description = "A great entry to Wizarding World! ";
        resources_a.Publisher = "Bloomsbury Children's Books, London, 2019";
        resources_a.DatePublished = Convert.ToDateTime("04/03/2015");

        resource resources_b = new resource();
        resources_b.Code = "https://www.worldcat.org/title/1004563508";
        resources_b.Title = "Harry Potter and the prisoner of Azkaban";
        resources_b.Description = "Welcome to the world Of magic!";
        resources_b.Publisher = "Arthur A. Levine Books, an imprint of Scholastic Inc., New York, NY, 2017";
        resources_b.DatePublished = Convert.ToDateTime("09/02/2014");

        List<resource> resources = new List<resource>();
        borrowing newborrow= new borrowing("ABCDEF", resources);
        newborrow.StartDate = Convert.ToDateTime("mm/dd/yyyy");
        newborrow.EndDate = Convert.ToDateTime("mm/dd/yyyy");
        
    }
}
