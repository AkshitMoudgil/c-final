using System;
using System.Security.Cryptography.X509Certificates;
public class borrowing:resource , Idownloadable
{
    public int ReferenceNumber;
    public string UserId="";
    public DateTime StartDate = Convert.ToDateTime("04/19/2023");
    public DateTime EndDate = Convert.ToDateTime("04/29/2023");
    public bool PickedUp;
    
    public List<resource>Resources = new List<resource>();


    public borrowing(string UserId, List<resource> resources)
    {
        this.UserId = UserId;
        this.Resources = resources;
    }

    public void ReturnResources(DateTime Date)
    {
        if(Date > EndDate)
        {
            Console.WriteLine("You have to pay a FINE! "); 
        }

        if (Date < EndDate)
        {
            Console.WriteLine("Thank you, Have a good day!");
        }

        PickedUp = true;

    }

    string Idownloadable.GenerateAccessLink()
    {
        return "asdfghjkl";
    }
}
