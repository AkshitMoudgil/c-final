public class User
{
    public int UserId;
    public string FirstName="";
    public string LastName="";
    public string Address="";
    public string PhoneNumber="";
    public void printBorrowingHistory()
    {
        Console.WriteLine("THE HISTORY");
    }
    public bool SendReminder()
    {
        return true;
    }
}