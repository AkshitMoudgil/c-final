public interface Idownloadable //:borrowing
{
    public string GenerateAccessLink()
    {
        return "";
    }
}