public class standard:User
{
    public string PostCode="";
    public string LibraryCardNbr="";
    private string CreditCardNbr="";
}