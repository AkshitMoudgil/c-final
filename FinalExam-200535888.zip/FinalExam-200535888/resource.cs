public class resource
{
    public string Code="";
    public string Title="";
    public string Description="";
    public string Publisher="";
    public DateTime DatePublished;
    public List<string> Resource = new List<string>();
}