public class student:User
{
    public int SchoolId;
    public string SchoolCardNbr="";
    private DateTime BirthDate;
}
